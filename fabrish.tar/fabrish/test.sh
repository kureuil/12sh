#!/bin/zsh

echo "Exec"
cat
