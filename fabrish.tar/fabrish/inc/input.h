/*
** input.h for fabrish in /home/person_l
** 
** Made by Louis Person
** Login   <person_l@epitech.net>
** 
** Started on  Mon Jan 26 16:52:26 2015 Louis Person
** Last update Mon Jan 26 16:56:26 2015 Louis Person
*/

#ifndef INPUT_H_
# define INPUT_H_

struct s_tree;

struct s_tree	*parse_input(char *, int);

#endif /* !INPUT_H_ */
