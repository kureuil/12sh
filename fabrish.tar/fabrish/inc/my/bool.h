/*
** bool.h for libmy in /home/person_l
**
** Made by Louis Person
** Login   <person_l@epitech.eu>
**
** Started on  Mon Dec  29 17:21:48 2014 Louis Person
** Last update Mon Dec  29 17:21:48 2014 Louis Person
*/

#ifndef MY_BOOL_H_
# define MY_BOOL_H_

typedef enum	e_bool
{
  false,
  true
}		t_bool;

#endif /* !MY_BOOL_H_ */
