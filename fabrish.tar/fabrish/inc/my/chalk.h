/*
** chalk.h for libmy in /home/person_l
**
** Made by Louis Person
** Login   <person_l@epitech.eu>
**
** Started on  Sat Dec  27 16:2:4 2014 Louis Person
** Last update Sat Dec  27 16:2:4 2014 Louis Person
*/

#ifndef MY_CHALK_H
# define MY_CHALK_H

void	chalk_red(char *str);
void	chalk_green(char *str);

#endif
