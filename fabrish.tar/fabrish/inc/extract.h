/*
** extract.h for fabrish in /home/person_l/rendu/minishell1/fabrish
** 
** Made by Louis Person
** Login   <person_l@epitech.net>
** 
** Started on  Fri Jan 30 13:01:35 2015 Louis Person
** Last update Fri Jan 30 13:02:23 2015 Louis Person
*/

#ifndef EXTRACT_H_
# define EXTRACT_H_

int	get_word_len(const char *);
char	*extract_word(char **);

#endif /* !ENXTRACT_H_ */
