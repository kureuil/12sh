/*
** errors.h for fabrish in /home/person_l
** 
** Made by Louis Person
** Login   <person_l@epitech.net>
** 
** Started on  Thu Jan 29 21:43:10 2015 Louis Person
** Last update Sun Feb  1 11:23:31 2015 Louis Person
*/

#ifndef ERRORS_H_
# define ERRORS_H_

# include "my/error.h"

void	error_no_file(char *);
void	error_no_right(char *);
t_error	parse_error(char *);

#endif /* ERRORS_H_ */
