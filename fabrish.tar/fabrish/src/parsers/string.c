/*
** string.c for fabrish in /home/person_l
** 
** Made by Louis Person
** Login   <person_l@epitech.net>
** 
** Started on  Thu Jan 29 10:30:30 2015 Louis Person
** Last update Thu Jan 29 21:21:34 2015 Louis Person
*/

#include "my.h"

t_error	parse_string()
{
  return (PARSE_ERROR);
}
