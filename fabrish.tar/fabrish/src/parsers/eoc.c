/*
** eoc.c for fabrish in /home/person_l
** 
** Made by Louis Person
** Login   <person_l@epitech.net>
** 
** Started on  Thu Jan 29 10:36:27 2015 Louis Person
** Last update Sun Feb  1 11:56:58 2015 Louis Person
*/

#include <stdlib.h>
#include "my.h"
#include "lexer.h"
#include "parser.h"
#include "errors.h"

t_error	parse_eoc(t_queue *queue, t_tree *parent)
{
  t_token	*token;
  t_tree	*node;
  t_token	*left;

  if ((token = queue->pop(queue)) == NULL)
    return (NULL_POINTER);
  if ((node = malloc(sizeof(t_tree))) == NULL)
    return (COULD_NOT_MALLOC);
  node->left = node->right = node->parent = node->data = NULL;
  left = NULL;
  if (parent->left != NULL)
    left = parent->left->data;
  if (parent->right != NULL ||
      (left != NULL &&
       (left->type == T_AND || left->type == T_OR) &&
       left->value == NULL))
    return (parse_error("syntax error near ;"));
  node->data = token;
  node->parent = parent;
  parent->right = node;
  return (parse(queue, node));
}
