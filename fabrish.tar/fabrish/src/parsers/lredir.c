/*
** lredir.c for fabrish in /home/person_l/rendu/minishell1/fabrish
** 
** Made by Louis Person
** Login   <person_l@epitech.net>
** 
** Started on  Fri Jan 30 13:09:34 2015 Louis Person
** Last update Sun Feb  1 11:46:38 2015 Louis Person
*/

#include <stdlib.h>
#include "my.h"
#include "lexer.h"
#include "parser.h"
#include "errors.h"

t_tree	*find_next_call(t_tree *node)
{
  if (node == NULL)
    return (NULL);
  if (((t_token *)node->data)->type == T_CALL)
    return (node);
  return (find_next_call(node->left));
}

t_error	parse_lredir(t_queue *queue, t_tree *parent)
{
  t_token	*token;
  t_tree	*copy;
  t_ttype	type;
  t_tree	*node;

  copy = parent;
  if ((token = queue->pop(queue)) == NULL)
    return (NULL_POINTER);
  if ((node = malloc(sizeof(t_tree))) == NULL)
    return (COULD_NOT_MALLOC);
  node->left = node->right = node->parent = node->data = NULL;
  type = ((t_token *)parent->left->data)->type;
  if (type != T_CALL && type != T_LREDIR && type != T_TLREDIR &&
      type != T_RREDIR)
    return (parse_error("syntax error near <"));
  if ((parent = find_next_call(parent)) == NULL)
    return (parse_error("syntax error near <"));
  parent = parent->parent;
  node->left = parent->left;
  parent->left->parent = node;
  node->parent = parent;
  parent->left = node;
  node->data = token;
  return (parse(queue, copy));
}
