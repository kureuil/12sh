/*
** rredir.c for fabrish in /home/person_l
** 
** Made by Louis Person
** Login   <person_l@epitech.net>
** 
** Started on  Sat Jan 31 11:00:08 2015 Louis Person
** Last update Sun Feb  1 12:01:17 2015 Louis Person
*/

#include <stdlib.h>
#include "my.h"
#include "lexer.h"
#include "parser.h"
#include "errors.h"

t_error		parse_rredir(t_queue *queue, t_tree *parent)
{
  t_token	*token;
  t_tree	*node;

  if (parent->right != NULL)
    return (parse_error("syntax error near >"));
  if ((token = queue->pop(queue)) == NULL)
    return (NULL_POINTER);
  if ((node = malloc(sizeof(t_tree))) == NULL)
    return (COULD_NOT_MALLOC);
  node->left = node->right = node->parent = node->data = NULL;
  node->parent = parent;
  parent->right = node;
  node->data = token;
  return (parse(queue, node));
}
