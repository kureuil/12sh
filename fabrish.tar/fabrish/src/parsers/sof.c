/*
** sof.c for fabrish in /home/person_l
** 
** Made by Louis Person
** Login   <person_l@epitech.net>
** 
** Started on  Thu Jan 29 10:37:32 2015 Louis Person
** Last update Thu Jan 29 21:20:38 2015 Louis Person
*/

#include "my.h"

t_error	parse_sof()
{
  return (PARSE_ERROR);
}
