/*
** extract.c for fabrish in /home/person_l/rendu/minishell1/fabrish
** 
** Made by Louis Person
** Login   <person_l@epitech.net>
** 
** Started on  Fri Jan 30 13:00:26 2015 Louis Person
** Last update Fri Jan 30 13:01:21 2015 Louis Person
*/

#include <stdlib.h>
#include "char.h"

int	get_word_len(const char *str)
{
  int	i;
  bool	quoted;
  int	q;

  if (str == NULL)
    return (-1);
  i = q = 0;
  quoted = false;
  while (str[i] != '\0' &&
	 (quoted == true ||
	  (quoted == false && char_is_regular(str[i]) == true)))
    {
      if (str[i] == '"')
	{
	  quoted = (quoted == true ? false : true);
	  q++;
	}
      i++;
    }
  if (quoted == false)
    return (i - q);
  return (-1);
}

char	*extract_word(char **str)
{
  int	i;
  int	len;
  char	*word;
  int	shift;

  if ((len = get_word_len(*str)) <= 0)
    return (NULL);
  if ((word = malloc(len + 1)) == NULL)
    return (NULL);
  i = -1;
  shift = 0;
  while (++i < len)
    {
      if ((*str)[i + shift] == '"')
        shift++;
      word[i] = (*str)[i + shift];
    }
  if (shift > 0)
    shift++;
  word[i] = '\0';
  (*str) += (i + shift);
  return (word);
}
