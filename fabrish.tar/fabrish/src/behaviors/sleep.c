/*
** sleep.c for fabrish in /home/person_l/rendu/minishell1/fabrish
** 
** Made by Louis Person
** Login   <person_l@epitech.net>
** 
** Started on  Wed Jan 28 23:43:37 2015 Louis Person
** Last update Thu Jan 29 21:18:20 2015 Louis Person
*/

#include "my.h"
#include "lexer.h"

t_error	behavior_sleep()
{
  return (OK);
}
