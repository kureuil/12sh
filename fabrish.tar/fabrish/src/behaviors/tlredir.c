/*
** tlredir.c<2> for fabrish in /home/person_l
** 
** Made by Louis Person
** Login   <person_l@epitech.net>
** 
** Started on  Sat Jan 31 10:06:43 2015 Louis Person
** Last update Sat Jan 31 10:09:50 2015 Louis Person
*/

#include <unistd.h>
#include "my.h"
#include "lexer.h"
#include "shell.h"

t_error	behavior_tlredir(t_token *token, t_shell *shell)
{
  if (shell->inpipe[0] == -1 && pipe(shell->inpipe) == -1)
    return (SYS_ERROR);
  write(shell->inpipe[1], token->value, my_strlen(token->value));
  my_dputchar(shell->inpipe[1], '\n');
  return (OK);
}
