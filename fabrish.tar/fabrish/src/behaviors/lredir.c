/*
** lredir.c<2> for fabrish in /home/person_l/rendu/minishell1/fabrish
** 
** Made by Louis Person
** Login   <person_l@epitech.net>
** 
** Started on  Fri Jan 30 13:27:59 2015 Louis Person
** Last update Sat Jan 31 10:12:35 2015 Louis Person
*/

#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdlib.h>
#include <fcntl.h>
#include "my.h"
#include "lexer.h"
#include "shell.h"

t_error	behavior_lredir(t_token *token, t_shell *shell)
{
  int	fd;

  if (shell->inpipe[0] == -1 && pipe(shell->inpipe) == -1)
    return (SYS_ERROR);
  fd = open(token->value, O_RDONLY);
  if (fd == -1)
    return (SYS_ERROR);
  copy(fd, shell->inpipe[1]);
  close(fd);
  return (OK);
}
