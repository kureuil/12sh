/*
** eoc.c<2> for fabrish in /home/person_l
** 
** Made by Louis Person
** Login   <person_l@epitech.net>
** 
** Started on  Fri Jan 30 18:57:02 2015 Louis Person
** Last update Sat Jan 31 18:01:53 2015 Louis Person
*/

#include <sys/types.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include "my.h"
#include "shell.h"
#include "lexer.h"

int	my_append(char **stream, int fd)
{
  int	readb;
  int	written;
  char	buffer[4096];
  char	*new;
  int	iter;

  written = 0;
  iter = 1;
  while ((readb = read(fd, buffer, 4096)) > 0)
    {
      if ((new = malloc(4096 * iter + 1)) == NULL)
	return (-1);
      my_strncpy(new, *stream, (iter - 1) * 4096);
      my_strncpy(new + (iter - 1) * 4096, buffer, readb);
      free(*stream);
      *stream = new;
      iter++;
      written += readb;
    }
  return (written);
}

void	flush(t_queue *queue, int pipe[2], char *outstream)
{
  char	*file;
  int	fd;
  int	len;

  len = my_append(&outstream, pipe[0]);
  while ((file = queue->pop(queue)) != NULL)
    {
      if ((fd = open(file, O_WRONLY | O_CREAT | O_TRUNC)) == -1)
	break;
      write(fd, outstream, len);
      close(fd);
    }
  close(pipe[0]);
}

t_error		behavior_eoc(t_token *token, t_shell *shell, t_tree *node)
{
  t_ttype	type;

  token = NULL;
  shell->inpipe[0] = shell->inpipe[1] = -1;
  type = ((t_token *)node->parent->data)->type;
  if (type == T_RREDIR || type == T_DRREDIR)
    flush(shell->output, shell->outpipe, shell->outstream);
  free(shell->outstream);
  shell->outstream = NULL;
  shell->outpipe[0] = shell->outpipe[1] = -1;
  type = ((t_token *)node->right->data)->type;
  if (type == T_RREDIR || type == T_DRREDIR)
    pipe(shell->outpipe);
  return (OK);
}
