/*
** sof.c for fabrish in /home/person_l
** 
** Made by Louis Person
** Login   <person_l@epitech.net>
** 
** Started on  Sat Jan 31 14:51:39 2015 Louis Person
** Last update Sat Jan 31 17:08:46 2015 Louis Person
*/

#include <unistd.h>
#include "my.h"
#include "lexer.h"
#include "shell.h"

t_error		behavior_sof(t_token *token, t_shell *shell, t_tree *node)
{
  t_ttype	type;

  token = NULL;
  type = ((t_token *)node->right->data)->type;
  if (type == T_RREDIR)
    {
      if (pipe(shell->outpipe) == -1)
	return (SYS_ERROR);
    }
  return (OK);
}
