/*
** rredir.c<2> for fabrish in /home/person_l
** 
** Made by Louis Person
** Login   <person_l@epitech.net>
** 
** Started on  Sat Jan 31 11:04:05 2015 Louis Person
** Last update Sat Jan 31 14:20:59 2015 Louis Person
*/

#include <stdlib.h>
#include "my.h"
#include "lexer.h"
#include "shell.h"

t_error		behavior_rredir(t_token *token, t_shell *shell)
{
  shell->output->add(shell->output, token->value);
  return (OK);
}
