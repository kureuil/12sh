/*
** redirections.c for fabrish in /home/person_l/rendu/minishell1/fabrish
** 
** Made by Louis Person
** Login   <person_l@epitech.net>
** 
** Started on  Fri Jan 30 11:36:41 2015 Louis Person
** Last update Sun Feb  1 11:48:23 2015 Louis Person
*/

#include <unistd.h>
#include <stdlib.h>
#include "my.h"
#include "char.h"
#include "lexer.h"
#include "extract.h"

t_token		*grammar_lredir(char **str)
{
  t_token	*res;

  res = NULL;
  if (my_strncmp("<", *str, 1))
    return (NULL);
  if (token_new(&res) == -1)
    return (NULL);
  res->type = T_LREDIR;
  *str += 1;
  skip_whitespace(str);
  if ((res->value = extract_word(str)) == NULL)
    return (NULL);
  if (access(res->value, F_OK) == -1)
    return (NULL);
  return (res);
}

t_token		*grammar_tlredir(char **str)
{
  t_token	*res;

  res = NULL;
  if (my_strncmp("<<<", *str, 3))
    return (NULL);
  if (token_new(&res) == -1)
    return (NULL);
  res->type = T_TLREDIR;
  *str += 3;
  skip_whitespace(str);
  if ((res->value = extract_word(str)) == NULL)
    return (NULL);
  return (res);
}

t_token		*grammar_rredir(char **str)
{
  t_token	*res;

  res = NULL;
  if (my_strncmp(">", *str, 1))
    return (NULL);
  if (token_new(&res) == -1)
    return (NULL);
  res->type = T_RREDIR;
  *str += 1;
  skip_whitespace(str);
  if ((res->value = extract_word(str)) == NULL)
    return (NULL);
  return (res);
}
