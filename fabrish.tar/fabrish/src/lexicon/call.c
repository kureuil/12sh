/*
** call.c for fabrish in /home/person_l
** 
** Made by Louis Person
** Login   <person_l@epitech.net>
** 
** Started on  Tue Jan 27 14:35:57 2015 Louis Person
** Last update Fri Jan 30 13:02:45 2015 Louis Person
*/

#include <stdbool.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include "my.h"
#include "char.h"
#include "lexer.h"
#include "extract.h"

t_token		*grammar_call(char **str)
{
  t_darray	*command;
  char		*word;
  t_token	*res;

  if ((command = create_dynamo(NULL)) == NULL)
    return (NULL);
  if (token_new(&res) == -1)
    return (NULL);
  res->type = T_CALL;
  while ((word = extract_word(str)) != NULL)
    {
      command->add(command, word);
      skip_whitespace(str);
    }
  command->add(command, NULL);
  res->value = command;
  return (res);
}
