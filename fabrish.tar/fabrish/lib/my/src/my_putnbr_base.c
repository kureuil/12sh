
/*
** my_putnbr_base.c for my_putnbr_base in /home/person_l/rendu/Piscine_C_J06/ex_07
** 
** Made by Louis Person
** Login   <person_l@epitech.net>
** 
** Started on  Mon Oct  6 17:21:48 2014 Louis Person
** Last update Mon Nov 17 14:22:07 2014 Louis Person
*/

#include "my.h"

int	my_putnbr_base(int n, char *base)
{
  return (my_dputnbr_base(1, n, base));
}
