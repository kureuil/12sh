/*
** my_char_iswordsep.c for libmy in /home/person_l
**
** Made by Louis Person
** Login   <person_l@epitech.eu>
**
** Started on  Sat Dec  27 18:23:21 2014 Louis Person
** Last update Sat Dec  27 18:23:21 2014 Louis Person
*/

int	my_char_iswordsep(const char c)
{
  return (c == ' ' || c == '\t');
}
